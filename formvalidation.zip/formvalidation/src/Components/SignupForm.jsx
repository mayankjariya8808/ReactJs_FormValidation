import React, { useState } from 'react'
// import './App.css';
function SignupForm() {
    let [state,setstate]=useState({
        email:"",
        password:""
    })
    const [arr,setarr]=useState([])
    const [isValid,setisValid]=useState(true)
    const register=(e)=>{
        let {name,value}=e.target
        setstate({...state,[name]:value})

    }
    const submit=(e)=>{
        e.preventDefault()
        setarr([...arr,state])
        console.log(state)
        setstate({
            email:"",
            password:""
        })
    }
    const blur=()=>{
        if(state.password.length > 8){
            setisValid(true)
        }else{
            setisValid(false)
        }
    }
  return (
    <div>
        <form className='border border-danger p-5 mt-5 ' onSubmit={submit} class="signupform">
            <h3 className='text-danger mt-3 mb-3'>SignUp Form</h3>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label text-danger"  >Email address</label>
    <input type="email" value={state.email} name='email' class="form-control" id="exampleInputEmail1"  aria-describedby="emailHelp" onChange={register} required />
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label text-danger">Password</label>
    <input type="password" value={state.password} name='password' class="form-control" id={isValid?"a":"b"}  onChange={register} onBlur={blur}required/>
    {isValid?"": <label className='text-danger'>Password Must be Greater then 8 Character</label>}
  </div>
<input type="submit" className='btn  btn-outline-danger float-end' />
</form>
    </div>
  )
}

export default SignupForm
