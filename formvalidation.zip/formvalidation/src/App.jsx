// import logo from './logo.svg';
import './App.css';
import SignupForm from './Components/SignupForm';

function App() {
  return (
    <div className="App">
      <SignupForm/>
      </div>
  );
}

export default App;
